# Pakiety
library(tidyverse)
library(RSNNS)
library(caret)
library(NeuralNetTools)

# Wczytanie danych
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv",
                 sep = ";", stringsAsFactors = TRUE)

# Normalizacja zmiennych numerycznych
num_vars <- c("age", "duration", "campaign", "pdays", "previous",
              "emp.var.rate", "cons.price.idx", "cons.conf.idx",
              "euribor3m", "nr.employed")
normalize <- function(x) (x - min(x)) / (max(x) - min(x))
bank[num_vars] <- lapply(bank[num_vars], normalize)

# Zmienna docelowa jako 0/1
bank$y_num <- ifelse(bank$y == "yes", 1, 0)

# One-hot encoding
X <- model.matrix(~ . - y - y_num, data = bank)
Y <- decodeClassLabels(bank$y_num)

# Podział danych (70% trening, 30% test)
set.seed(123)
split <- splitForTrainingAndTest(X, Y, ratio = 0.3)

# Trening sieci (1 warstwa ukryta, 15 neuronów)
model <- mlp(split$inputsTrain, split$targetsTrain, size = 15,
             learnFuncParams = 0.1, maxit = 50,
             inputsTest = split$inputsTest, targetsTest = split$targetsTest)

# Wykres sieci
plotnet(model)

# Predykcja
pred <- predict(model, split$inputsTest)

# ROC
plotROC(pred[,1], split$targetsTest[,1])

# Błąd uczenia
plotIterativeError(model)

# Wyniki
pred_class <- factor(encodeClassLabels(round(pred, 0)))
true_class <- factor(encodeClassLabels(split$targetsTest))
confusionMatrix(true_class, pred_class)



