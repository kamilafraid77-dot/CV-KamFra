library(tidyverse)
library(class)
library(caret)

# Wczytanie danych
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv", sep = ";", stringsAsFactors = TRUE)

# Zmniejszenie zbioru danych do 5000 rekordów
set.seed(1234)
bank_small <- bank %>% sample_n(5000)

# Podgląd danych
glimpse(bank_small)
summary(bank_small)

# Wybranie zmiennych numerycznych do normalizacji
num_vars <- c("age", "duration", "campaign", "pdays", "previous", "emp.var.rate", 
              "cons.price.idx", "cons.conf.idx", "euribor3m", "nr.employed")

# Funkcja do normalizacji min-max
normalize <- function(x) (x - min(x)) / (max(x) - min(x))

# Normalizacja zmiennych numerycznych z mutate i across
bank_small <- bank_small %>%
  mutate(across(all_of(num_vars), normalize))

# Zmiana zmiennej docelowej na faktor i wymuszenie spójnych poziomów
bank_small$y <- factor(bank_small$y, levels = c("no", "yes"))

# One-hot encoding bez interceptu (model.matrix zwraca macierz)
bank_mat <- model.matrix(~ . - 1, data = bank_small %>% select(-y))

# Podział na zbiór treningowy i testowy 75%/25%
set.seed(1234)
sample_index <- sample(seq_len(nrow(bank_mat)), size = floor(0.75 * nrow(bank_mat)))

bank_train <- bank_mat[sample_index, ]
bank_test <- bank_mat[-sample_index, ]

bank_train_labels <- bank_small$y[sample_index]
bank_test_labels <- bank_small$y[-sample_index]

# Sprawdzenie dokładności modelu dla różnych k
k_values <- seq(1, 25, by = 5)
accuracies <- numeric(length(k_values))
for (i in seq_along(k_values)) {
  k <- k_values[i]
  
  pred <- knn(train = bank_train, test = bank_test, cl = bank_train_labels, k = k)
  
  # Konwersja pred na faktor z tymi samymi poziomami co test_labels
  pred <- factor(pred, levels = levels(bank_test_labels))
  
  # Użycie confusionMatrix z pakietu caret
  cm <- caret::confusionMatrix(pred, bank_test_labels)
  
  accuracies[i] <- cm$overall["Accuracy"]
}


# Utworzenie ramki danych do wykresu
results_df <- data.frame(k = k_values, Accuracy = accuracies)

# Wykres zależności dokładności od k
ggplot(results_df, aes(x = k, y = Accuracy)) +
  geom_line(color = "blue") +
  geom_point(color = "red") +
  labs(title = "Wpływ liczby sąsiadów k na dokładność modelu KNN (próbka 5000 rekordów)",
       x = "Liczba sąsiadów k",
       y = "Dokładność (Accuracy)") +
  theme_minimal()


#### 2 wersja 

library(tidyverse)
library(class)
library(caret)

# Wczytanie danych
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv", sep = ";", stringsAsFactors = TRUE)

# Podgląd danych
glimpse(bank)
summary(bank)


# Wybranie zmiennych numerycznych do normalizacji (dopasuj do swojego zbioru)
num_vars <- c("age", "duration", "campaign", "pdays", "previous", "emp.var.rate", 
              "cons.price.idx", "cons.conf.idx", "euribor3m", "nr.employed")

# Funkcja do normalizacji min-max
normalize <- function(x) (x - min(x)) / (max(x) - min(x))

# Normalizacja zmiennych numerycznych
bank[num_vars] <- lapply(bank[num_vars], normalize)

# Zmiana zmiennej docelowej na faktor (np. y: tak/nie)
bank$y <- as.factor(bank$y)

# Zmienne kategoryczne do zakodowania - pobierz te, które są factorami poza y i num_vars
cat_vars <- setdiff(names(bank)[sapply(bank, is.factor)], "y")

# Zamiana na macierz modelową z one-hot encoding bez interceptu
bank_mat <- model.matrix(~ . - 1, data = bank %>% select(-y))

# Podział na zbiór treningowy i testowy 75%/25%
set.seed(1234)
sample_index <- sample(seq_len(nrow(bank_mat)), size = floor(0.75 * nrow(bank_mat)))

bank_train <- bank_mat[sample_index, ]
bank_test <- bank_mat[-sample_index, ]

bank_train_labels <- bank$y[sample_index]
bank_test_labels <- bank$y[-sample_index]

# Budowa i ocena modelu KNN dla różnych wartości k
knn_predict_and_eval <- function(k) {
  pred <- knn(train = bank_train, test = bank_test, cl = bank_train_labels, k = k)
  cat("\nConfusion Matrix dla k =", k, "\n")
  print(confusionMatrix(pred, bank_test_labels))
}

# Testowanie dla przykładowych k
for (k in c(1, 7, 15)) {
  knn_predict_and_eval(k)
}




