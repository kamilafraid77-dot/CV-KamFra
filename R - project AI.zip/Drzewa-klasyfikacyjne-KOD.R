# Pakiety
library(tidyverse)
library(rpart)
library(rpart.plot)
library(tree)
library(caret)
library(ROCR)

# Wczytanie danych
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv",
                 sep = ";", stringsAsFactors = TRUE)

# Podgląd danych
glimpse(bank)

# Konwersja zmiennej celu do typu logicznego lub faktorowego
bank$y <- as.factor(bank$y)

# Podział na zbiór treningowy i testowy
set.seed(1234)
train_index <- sample(nrow(bank), 0.75 * nrow(bank))
bank_train <- bank[train_index, ]
bank_test <- bank[-train_index, ]

# Propocje klas
round(prop.table(table(bank$y)), 2)
round(prop.table(table(bank_train$y)), 2)
round(prop.table(table(bank_test$y)), 2)

# -------------------
# MODEL: rpart
# -------------------

# Trening drzewa
bank_rpart <- rpart(y ~ ., data = bank_train, method = "class", cp = 0.01)

# Wizualizacja drzewa
rpart.plot(bank_rpart)

# Predykcja
pred_rpart <- predict(bank_rpart, bank_test, type = "class")

# Macierz pomyłek
confusionMatrix(pred_rpart, bank_test$y)

# Prawdopodobieństwa dla ROC
pred_prob_rpart <- predict(bank_rpart, bank_test, type = "prob")

# ROC + AUC
roc_rpart <- prediction(pred_prob_rpart[, "yes"], bank_test$y)
perf_rpart <- performance(roc_rpart, "tpr", "fpr")
plot(perf_rpart, main = "ROC Curve (rpart)", col = "blue", lwd = 2)
abline(a = 0, b = 1, lty = 2)
auc_rpart <- performance(roc_rpart, "auc")
unlist(slot(auc_rpart, "y.values"))

# -------------------
# MODEL: tree
# -------------------

# Trening
bank_tree <- tree(y ~ ., data = bank_train)

# Wizualizacja
plot(bank_tree)
text(bank_tree)

# Predykcja
pred_tree <- predict(bank_tree, bank_test, type = "class")
confusionMatrix(pred_tree, bank_test$y)

# Prawdopodobieństwa dla ROC
pred_prob_tree <- predict(bank_tree, bank_test, type = "vector")
roc_tree <- prediction(pred_prob_tree[, "yes"], bank_test$y)
perf_tree <- performance(roc_tree, "tpr", "fpr")
plot(perf_tree, main = "ROC Curve (tree)", col = "darkgreen", lwd = 2)
abline(a = 0, b = 1, lty = 2)
auc_tree <- performance(roc_tree, "auc")
unlist(slot(auc_tree, "y.values"))
