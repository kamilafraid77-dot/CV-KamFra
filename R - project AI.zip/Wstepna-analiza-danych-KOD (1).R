## ANALIZA DANYCH

# WYMAGANE PAKIETY
library(ggplot2)
library(dplyr)
library(Amelia)
library(corrplot)

# 1. WCZYTANIE DANYCH
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv", sep = ";")

# 2. PODGLĄD I BRAKI
print(str(bank))
print(summary(bank))

# Sprawdzenie braków danych
print(colSums(is.na(bank)))

# 3. KONWERSJA ZMIENNYCH KATEGORYCZNYCH
bank <- bank %>%
  mutate(
    job = factor(job),
    marital = factor(marital),
    education = factor(education),
    default = factor(default),
    housing = factor(housing),
    loan = factor(loan),
    contact = factor(contact),
    month = factor(month),
    day_of_week = factor(day_of_week),
    poutcome = factor(poutcome),
    y = factor(y)
  )

# 4. KORELACJA ZMIENNYCH NUMERYCZNYCH
numeric_vars <- bank %>%
  select(age, campaign, pdays, previous)  # można dodać więcej jeśli są dostępne

cor_matrix <- cor(numeric_vars, use = "complete.obs")
corrplot(cor_matrix, method = "color", type = "upper", tl.cex = 0.8, addCoef.col = "black")

# 5. WYKRESY

# Histogram wieku
ggplot(bank, aes(x = age)) +
  geom_histogram(binwidth = 5, fill = "lightgreen", color = "black") +
  theme_minimal() +
  labs(title = "Rozkład wieku klientów", x = "Wiek", y = "Liczba klientów")

# Boxplot: Kampania vs. decyzja o lokacie
ggplot(bank, aes(x = y, y = campaign, fill = y)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "Liczba kontaktów a decyzja o lokacie", x = "Decyzja", y = "Liczba kontaktów")

# Boxplot: Wiek a decyzja
ggplot(bank, aes(x = y, y = age, fill = y)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "Wiek klienta vs. decyzja o lokacie", x = "Decyzja", y = "Wiek")

# Słupkowy: Stan cywilny vs. decyzja
ggplot(bank, aes(x = marital, fill = y)) +
  geom_bar(position = "fill") +
  theme_minimal() +
  labs(title = "Stan cywilny a decyzja o lokacie", x = "Stan cywilny", y = "Proporcja")

# Słupkowy: Edukacja vs. decyzja
ggplot(bank, aes(x = education, fill = y)) +
  geom_bar(position = "fill") +
  theme_minimal() +
  labs(title = "Wykształcenie a decyzja o lokacie", x = "Poziom wykształcenia", y = "Proporcja")

# Słupkowy: Zawód vs. decyzja
ggplot(bank, aes(x = job, fill = y)) +
  geom_bar(position = "fill") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(title = "Zawód klienta a decyzja o lokacie", x = "Zawód", y = "Proporcja")
