# Pakiety
library(tidyverse)
library(AMORE)
library(caret)

# Wczytanie danych
bank <- read.csv("C:/Users/kamil/OneDrive/Pulpit/REFERAT AI/bank-additional-full.csv",
                 sep = ";", stringsAsFactors = TRUE)

# Normalizacja zmiennych numerycznych
num_vars <- c("age", "duration", "campaign", "pdays", "previous",
              "emp.var.rate", "cons.price.idx", "cons.conf.idx",
              "euribor3m", "nr.employed")
normalize <- function(x) (x - min(x)) / (max(x) - min(x))
bank[num_vars] <- lapply(bank[num_vars], normalize)

# Zmienna docelowa jako 0/1
bank$y_num <- ifelse(bank$y == "yes", 1, 0)

# One-hot encoding
X <- as.matrix(model.matrix(~ . - y - y_num, data = bank))
Y <- as.vector(bank$y_num)

# Podział na zbiór treningowy i testowy (70/30)
set.seed(123)
n <- nrow(X)
train_idx <- sample(1:n, size = 0.7 * n)
X_train <- X[train_idx, ]
Y_train <- Y[train_idx]
X_test <- X[-train_idx, ]
Y_test <- Y[-train_idx]

# Budowa modelu (sieć: 3 ukryte warstwy)
net <- newff(n.neurons = c(ncol(X), 30, 15, 10, 1),
             learning.rate.global = 1e-2,
             momentum.global = 0.5,
             error.criterium = "LMS",
             hidden.layer = "tansig",
             output.layer = "purelin",
             method = "ADAPTgdwm")

# Trening
result <- train(net, X_train, Y_train, X_test, Y_test,
                error.criterium = "LMS", report = TRUE,
                show.step = 100, n.shows = 20)

# Predykcja
pred <- sim(result$net, X_test)
pred_bin <- round(pred, 0)

# Wykres błędu
matplot(result$Merror, pch = 21:23, bg = c("white", "black"),
        type = "o", col = "black",
        xlab = "Iteracje", ylab = "Błąd",
        main = "Błąd podczas uczenia (AMORE)")

# Ocena
confusionMatrix(factor(pred_bin), factor(Y_test))
